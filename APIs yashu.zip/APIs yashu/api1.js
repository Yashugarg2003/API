const request = require('request');

const fullName = "Your Full Name";
const email = "your_colle@example.com";
const rollNumber = 123456; 
const phone = "+1234567890";

const data = {
  name: fullName,
  email: email,
  rollNumber: rollNumber,
  phone: phone,
};

const options = {
  url: 'https://customer-analytics-34146.my.salesforce-sites.com/services/apexrest/createAccount',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  json: data,
};

request(options, (error, response, body) => {
  if (error) {
    console.error('Error sending request:', error);
  } else {
    console.log('Status:', response.statusCode);
    console.log('Body:', body);
  }
});