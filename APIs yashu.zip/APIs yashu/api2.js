const request = require('request');

const rollNumber = 123456;
const company = "Company Name"; 
const currentPrice = 100.00; 
const githubRepoLink = "https://github.com/your-username"; 


let accountNumber = null;


function handleAccountCreated(data) {
  if (data && data.accountNumber) {
    accountNumber = data.accountNumber;
    buyStocks();
  } else {
    console.error("Failed to retrieve account number. Cannot buy stocks.");
  }
}

function buyStocks() {
  const options = {
    url: 'https://customer-analytics-34146.my.salesforce-sites.com/services/apexrest/buyStocks',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'bfhl-auth': rollNumber,
    },
    json: {
      company: company,
      currentPrice: currentPrice,
      accountNumber: accountNumber,
      githubRepoLink: githubRepoLink,
    },
  };

  request(options, (error, response, body) => {
    if (error) {
      console.error('Error sending request:', error);
    } else {
      console.log('Status:', response.statusCode);
      console.log('Body:', body);
    }
  });
}

const mockAccountData = { accountNumber: 987654 };
handleAccountCreated(mockAccountData);